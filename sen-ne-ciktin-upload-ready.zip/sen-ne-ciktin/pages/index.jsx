
import Test from '../components/Test';

export default function Home() {
  return (
    <div>
      <h1 style={{ textAlign: 'center', marginTop: 20 }}>Sen Ne Çıktın?</h1>
      <Test />
    </div>
  );
}
